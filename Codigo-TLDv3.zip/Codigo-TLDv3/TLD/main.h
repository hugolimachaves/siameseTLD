#include "tracking/TLD.hpp"
#include <stdlib.h>

extern "C"{
    void initializer_TLD(char *parameters_path);
    void TLD_function_1(int *frame, float *array_bb_candidates, int *size_candidates, 
    					float *array_object_model_positive, int *size_positive, 
    					float *array_object_model_negative, int *size_negative);
    void TLD_function_2(/* Colocar os Parametros */); // 256 * 100
}
