#include "main.h"

extern "C"{
    void initializer_TLD(char *parameters_path){
        init_TLD(parameters_path);
    }
    void TLD_function_1(int *frame, float *array_bb_candidates, int *size_candidates, 
    					float *array_object_model_positive, int *size_positive, 
    					float *array_object_model_negative, int *size_negative){
    	
        TLD_part_1(frame, array_bb_candidates, size_candidates, 
        		   array_object_model_positive, size_positive, 
        		   array_object_model_negative, size_negative);
    }
    void TLD_function_2(/* Colocar os Parametros */){
        TLD_part_2(/* Colocar os Parametros */);
    }
}
